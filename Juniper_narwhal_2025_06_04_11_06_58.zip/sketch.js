let quiz = [
  {
    pergunta: "Qual brincadeira consiste em correr com as pernas dentro de um saco?",
    opcoes: ["Pescaria", "Corrida do Saco", "Cabo de Guerra", "Dança da Cadeira"],
    correta: 1
  },
  {
    pergunta: "Em qual brincadeira usamos uma vara para pegar prêmios?",
    opcoes: ["Corrida de Ovo na Colher", "Pescaria", "Corrida do Saco", "Cabo de Guerra"],
    correta: 1
  },
  {
    pergunta: "Qual brincadeira envolve puxar uma corda em equipes?",
    opcoes: ["Cabo de Guerra", "Dança da Cadeira", "Pescaria", "Corrida do Saco"],
    correta: 0
  },
  {
    pergunta: "Nesta brincadeira, você precisa sentar quando a música para:",
    opcoes: ["Corrida do Saco", "Pescaria", "Dança da Cadeira", "Cabo de Guerra"],
    correta: 2
  },
  {
    pergunta: "Em qual brincadeira se equilibra um ovo em uma colher?",
    opcoes: ["Pescaria", "Corrida de Ovo na Colher", "Cabo de Guerra", "Dança da Cadeira"],
    correta: 1
  }
];

let estado = 'inicio';
let indice = 0;
let acertos = 0;

function setup() {
  createCanvas(600, 400);
  textAlign(CENTER, CENTER);
  textSize(20);
}

function draw() {
  background(240, 230, 200);

  if (estado === 'inicio') {
    mostrarInicio();
  } else if (estado === 'quiz') {
    mostrarPergunta();
  } else if (estado === 'resultado') {
    mostrarResultado();
  }
}

function mostrarInicio() {
  fill(50);
  textSize(30);
  text("Quiz: Brincadeiras do Campo e da Cidade", width / 2, height / 2 - 50);
  
  fill(200, 100, 100);
  rect(width / 2 - 75, height / 2, 150, 50, 10);
  
  fill(255);
  textSize(20);
  text("Começar", width / 2, height / 2 + 25);
}

function mostrarPergunta() {
  let q = quiz[indice];
  
  fill(50);
  textSize(24);
  text(q.pergunta, width / 2, 50);
  
  for (let i = 0; i < q.opcoes.length; i++) {
    let y = 120 + i * 60;
    
    fill(150, 200, 250);
    rect(width / 2 - 200, y, 400, 40, 10);
    
    fill(0);
    textSize(18);
    text(q.opcoes[i], width / 2, y + 20);
  }
}

function mostrarResultado() {
  fill(50);
  textSize(30);
  text("Fim do Quiz!", width / 2, height / 2 - 50);
  
  textSize(24);
  text(`Você acertou ${acertos} de ${quiz.length}`, width / 2, height / 2);
}

function mousePressed() {
  if (estado === 'inicio') {
    if (mouseX > width / 2 - 75 && mouseX < width / 2 + 75 &&
        mouseY > height / 2 && mouseY < height / 2 + 50) {
      estado = 'quiz';
    }
  } else if (estado === 'quiz') {
    checarResposta();
  } else if (estado === 'resultado') {
    estado = 'inicio';
    indice = 0;
    acertos = 0;
  }
}

function checarResposta() {
  let q = quiz[indice];
  
  for (let i = 0; i < q.opcoes.length; i++) {
    let y = 120 + i * 60;
    
    if (mouseX > width / 2 - 200 && mouseX < width / 2 + 200 &&
        mouseY > y && mouseY < y + 40) {
      if (i === q.correta) {
        acertos++;
        flashMensagem("Certo!", color(100, 200, 100));
      } else {
        flashMensagem("Errado!", color(200, 100, 100));
      }
      
      indice++;
      if (indice >= quiz.length) {
        estado = 'resultado';
      }
    }
  }
}

function flashMensagem(msg, cor) {
  fill(cor);
  rect(0, height - 50, width, 50);
  fill(255);
  textSize(24);
  text(msg, width / 2, height - 25);
}
